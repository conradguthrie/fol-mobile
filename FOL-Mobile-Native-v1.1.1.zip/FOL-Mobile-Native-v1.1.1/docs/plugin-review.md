# Plugin integration notes
The original FOL plugin uses the `wp_fol_orders`, `wp_fol_tracking_events`, and `wp_fol_drivers` table families (actual prefix varies by WordPress installation). The companion API exposes public tracking, authenticated customer shipments, staff summary/search/status routes, and driver jobs. This native client currently consumes health-independent routes `/track/{code}`, `/me`, `/customer/shipments`, `/staff/summary`, `/staff/shipments`, and `/driver/jobs`.

API route security and database schema must be reviewed on staging before production deployment. Application Password authentication requires WordPress core support and must be over HTTPS.
