# Build the Fast One Logistics Android APK using only your phone

This starter loads https://f1logisticsja.online/ in an Android WebView. It is not a native rewrite of the WordPress plugin. The APK created by the workflow is a **debug/test APK**, not a Play Store release.

## Steps
1. Sign in to GitHub or create an account at https://github.com/.
2. In GitHub, create a new repository named `fol-mobile` (a free private repository is fine).
3. In the repository, use **Add file → Upload files** and upload the contents of this ZIP, including the hidden `.github` folder. If your mobile browser hides dot-folders, use GitHub's web editor to create `.github/workflows/android-apk.yml` and paste the workflow from this project.
4. Commit the uploaded files.
5. Open the repository's **Actions** tab. Select **Build Android APK** and tap **Run workflow** (or wait for the push-triggered build).
6. Open the completed workflow run, scroll to **Artifacts**, and download `FOL-Android-debug-APK`.
7. Extract the downloaded artifact ZIP on your phone; it contains `app-debug.apk`. Tap the APK to install. Android may ask you to allow installation from that browser/file manager; only allow this for the APK you built from your own repository.

## Important limitations
- You need internet access for the app to load the website.
- Test login, shipment tracking, calculator, uploads, invoices, and back navigation on the phone.
- This debug APK is for testing and is not a signed production release. Do not distribute it as a final customer app.
- iOS cannot be built or installed as a normal app directly from an Android phone. To make an iOS build, use a Mac with Xcode or a hosted macOS build service and configure Apple signing. App Store release requires Apple Developer account and review.
- Before publishing, review privacy disclosures, website permissions, app icon, domain navigation, and the site's mobile behavior.
