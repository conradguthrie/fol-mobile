import SwiftUI

@main
struct FOLMobileApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
