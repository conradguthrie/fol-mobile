import SwiftUI
import WebKit

// Add this file to a SwiftUI iOS App target in Xcode.
struct ContentView: View {
    // Fast One Logistics production website.
    private let siteURLString = "https://f1logisticsja.online/"

    var body: some View {
        Group {
            if let url = URL(string: siteURLString) {
                FOLWebView(url: url).ignoresSafeArea(edges: .bottom)
            }
        }
    }
}

struct FOLWebView: UIViewRepresentable {
    let url: URL
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        let view = WKWebView(frame: .zero, configuration: config)
        view.allowsBackForwardNavigationGestures = true
        view.load(URLRequest(url: url))
        return view
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}
