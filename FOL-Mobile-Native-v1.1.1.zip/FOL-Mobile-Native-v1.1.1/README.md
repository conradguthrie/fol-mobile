# Fast One Logistics Native Android App (v1.1.1)

This project replaces the old single-WebView home screen with native Android screens connected to the installed WordPress Mobile API at `https://f1logisticsja.online/wp-json/fol-mobile/v1`.

## Implemented native screens
- Home navigation
- Public shipment tracking with tracking events
- WordPress Application Password sign-in and current-user verification
- Customer shipment list
- Staff shipment summary, shipment search and shipment-status updates
- Driver assigned-jobs list

## Security and setup
- Network traffic uses HTTPS.
- Customer data routes require WordPress authentication; staff routes enforce capabilities on the server; driver jobs require a linked driver profile.
- Sign-in uses a WordPress **Application Password**, not the normal account password. Create one in WordPress Users → Profile → Application Passwords, and revoke it after testing if needed.
- This app stores credentials only in current in-memory session state; they are cleared by the Sign out button or app process exit.
- Public tracking is intentionally public and only returns fields exposed by the API.

## Build APK from a phone
Upload this folder's contents to your existing `fol-mobile` GitHub repository, replacing the old starter files, commit, then open Actions → Build Android APK. Download the `FOL-Android-debug-APK` artifact from a successful run. See `PHONE-BUILD-GUIDE.md`.

## Scope and verification
This is a native-screen integration milestone, not a claim that every original plugin feature is implemented. It relies on the installed companion API and should be tested against a staging site first. Invoice downloads, creating shipments, price calculator, push notifications, GPS, barcode/QR, payments, collection workflows, full CRUD, and complete admin reports remain future integration work.
